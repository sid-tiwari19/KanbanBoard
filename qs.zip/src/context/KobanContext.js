import { createContext } from "react";

const KobanContext = createContext();

export default KobanContext;

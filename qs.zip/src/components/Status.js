import React, { useContext, useEffect, useState } from "react";
import Done from "@mui/icons-material/CheckCircle";
import Warning from "@mui/icons-material/Warning";
import Progress from "@mui/icons-material/HistoryToggleOff";
import Todo from "@mui/icons-material/Event";
import Cancelled from "@mui/icons-material/Cancel";
import kobanContext from "../context/KobanContext";

export const Status = ({ tickets }) => {
  const context = useContext(kobanContext);
  const { order } = context;
  const [ans, setAns] = useState([]);

  const status = ["Backlog", "Todo", "In progress", "Completed", "Cancelled"];
  const key = [
    <Warning className="ico" sx={{ color: "red" }} />,
    <Todo className="ico" sx={{ color: "blue" }} />,
    <Progress className="ico" sx={{ color: "orange" }} />,
    <Done className="ico" color="success" />,
    <Cancelled className="ico" sx={{ color: "grey" }} />,
  ];
  const arr = [];

  status.forEach((stat) => {
    arr.push(tickets.filter((ticket) => ticket.status === stat));
  });

  useEffect(() => {
    const newArr = arr.map((val) => {
      if (order === "priority") {
        return val.slice().sort((a, b) => b.priority - a.priority);
      } else {
        return val
          .slice()
          .sort((a, b) =>
            a.title.toLowerCase().localeCompare(b.title.toLowerCase())
          );
      }
    });
    setAns(newArr);
  }, [order]);

  return (
    <div className="bucket">
      {ans.map((stat, index) => (
        <div key={index} className="col">
          {key[index]}
          <span>{status[index]}</span>
          {stat.map((ticket) => (
            <div key={ticket.id} className="card">
              <h2 className="card-title">{ticket.id}</h2>
              <p className="card-content">
                <div>
                  <h3>{ticket.title}</h3>
                  <p>Status: {ticket.status}</p>
                  <p>User: {ticket.userId}</p>
                  <p>Priority: {ticket.priority}</p>
                </div>
              </p>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

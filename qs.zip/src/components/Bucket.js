import React, { useContext } from "react";
import kobanContext from "../context/KobanContext";
import { Status } from "./Status";
import { Priority } from "./Priority";
import { User } from "./User";
export const Bucket = ({ tickets, users }) => {
  const context = useContext(kobanContext);
  const { group } = context;

  return (
    <div>
      {group === "status" && <Status tickets={tickets} />}
      {group === "priority" && <Priority tickets={tickets} />}
      {group === "user" && <User users={users} tickets={tickets} />}
    </div>
  );
};

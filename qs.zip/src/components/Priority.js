import React, { useContext, useEffect, useState } from "react";
import Low from "@mui/icons-material/SignalCellularAlt1Bar";
import Medium from "@mui/icons-material/SignalCellularAlt2Bar";
import High from "@mui/icons-material/SignalCellularAlt";
import Urgent from "@mui/icons-material/PriorityHigh";
import Nop from "@mui/icons-material/Pending";
import kobanContext from "../context/KobanContext";

export const Priority = ({ tickets }) => {
  const context = useContext(kobanContext);
  const { order } = context;
  const [ans, setAns] = useState([]);

  const priority = ["No priority", "Low", "Medium", "High", "Urgent"];
  const key = [
    <Nop className="ico" sx={{ color: "grey" }} />,
    <Low className="ico" />,
    <Medium className="ico" />,
    <High className="ico" />,
    <Urgent className="ico" sx={{ color: "red" }} />,
  ];
  const arr = [];

  priority.forEach((stat, index) => {
    arr.push(tickets.filter((ticket) => ticket.priority === index));
  });

  useEffect(() => {
    const newArr = arr.map((val) => {
      if (order === "priority") {
        return val.slice().sort((a, b) => b.priority - a.priority);
      } else {
        return val
          .slice()
          .sort((a, b) =>
            a.title.toLowerCase().localeCompare(b.title.toLowerCase())
          );
      }
    });
    setAns(newArr);
  }, [order]);

  return (
    <div className="bucket">
      {ans.map((stat, index) => (
        <div key={index} className="col">
          {key[index]}
          <span>{priority[index]}</span>
          {stat.map((ticket) => (
            <div key={ticket.id} className="card">
              <h2 className="card-title">{ticket.id}</h2>
              <p className="card-content">
                <div>
                  <h3>{ticket.title}</h3>
                  <p>Status: {ticket.status}</p>
                  <p>User: {ticket.userId}</p>
                  <p>Priority: {ticket.priority}</p>
                </div>
              </p>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

import React, { useState, useContext } from "react";
import Settings from "@mui/icons-material/SettingsInputComponentSharp";
import DropDown from "@mui/icons-material/ArrowDropDownSharp";
import KobanContext from "../context/KobanContext";

const Modal = ({ isOpen, onClose, children }) => {
  const handleOverlayClick = (e) => {
    // Close the modal only if the click is on the overlay (outside the modal content)
    if (e.target.classList.contains("modal-overlay")) {
      onClose();
    }
  };

  return (
    <>
      {isOpen && (
        <div className="modal-overlay" onClick={handleOverlayClick}>
          <div className="modal">
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              {children}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

const Dropdown = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleOptionChange = (event) => {
    setGroup(event.target.value);
    console.log(group);
  };
  const handleOptionChange2 = (event) => {
    setOrder(event.target.value);
  };

  const context = useContext(KobanContext);
  const { order, group, setOrder, setGroup } = context;

  const styles = {
    select: {
      padding: "6px",
      fontSize: "14px",
      border: "1px solid #ccc",
      borderRadius: "4px",
      width: "7vw",
      margin: "5px",
      cursor: "pointer",
    },
    para: {
      margin: "10px",
      marginRight: "5px",
      width: "10vw",
    },
    box: { display: "flex" },
    ico: { fontSize: "15px", margin: "5px" },
    btn: {
      margin: "5px",
    },
  };

  return (
    <div>
      <button className="d-btn" onClick={openModal}>
        <Settings style={styles.ico} />
        <span style={styles.btn}>Display</span>
        <DropDown style={styles.ico} />
      </button>

      <Modal isOpen={isModalOpen} onClose={closeModal}>
        <div style={styles.box}>
          <p style={styles.para}>Grouping</p>
          <select
            id="dropdown"
            value={group}
            onChange={handleOptionChange}
            style={styles.select}
          >
            <option value="status">Status</option>
            <option value="user">User</option>
            <option value="priority">Priority</option>
          </select>
        </div>
        <div style={styles.box}>
          <p style={styles.para}>Ordering</p>
          <select
            id="dropdown"
            value={order}
            onChange={handleOptionChange2}
            style={styles.select}
          >
            <option value="priority">Priority</option>
            <option value="title">Title</option>
          </select>
        </div>
      </Modal>
    </div>
  );
};

export default Dropdown;
